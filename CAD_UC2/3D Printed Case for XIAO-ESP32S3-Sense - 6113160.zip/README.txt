3D Printed Case for XIAO-ESP32S3-Sense by kawa_kunimasa on Thingiverse: https://www.thingiverse.com/thing:6113160

Summary:
3D Printed Case for XIAO-ESP32S3-Sensewith heat sink ( 10 x 14 x 8 mm ), picture for details: case_top_b.stl and case_bottom_b.stlwithout heat sink: case_top.stl and case_bottom.stl